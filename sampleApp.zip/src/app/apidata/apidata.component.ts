import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apidata',
  templateUrl: './apidata.component.html',
  styleUrls: ['./apidata.component.css']
})
export class ApidataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
