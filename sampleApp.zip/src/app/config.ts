export class Config {
    public data = [{
        "country" : "India",
        "segment" : "Government",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },
    {
        "country" : "Canada",
        "segment" : "MidMarket",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "Germany",
        "segment" : "private",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "France",
        "segment" : "Government",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "Italy",
        "segment" : "MidMarket",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "Australia",
        "segment" : "Travel",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "Nepal",
        "segment" : "Travel",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "Pakistan",
        "segment" : "Government",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },
    {
        "country" : "Afghanistan",
        "segment" : "MidMarket",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "Brazil",
        "segment" : "private",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "China",
        "segment" : "Government",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "Vietnam",
        "segment" : "MidMarket",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "SriLanka",
        "segment" : "Travel",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },{
        "country" : "Russia",
        "segment" : "Travel",
        "product" : "abcd",
        "unitsSold" : 1618.5,
        "manufacturingPrice" : "3.00",
        "salePrice" : "5.00",
        "grossSale" : "32,9767"
    },]
}
